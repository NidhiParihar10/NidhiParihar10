const form = document.querySelector('form');
const fullname = document.getElementById("name"); 
const email = document.getElementById("email"); 
const phone = document.getElementById("phome"); 
const subject = document.getElementById("subject"); 
const messa = document.getElementById("message"); 


function sendMail()
{
    const bodymessgae = 'Full Name: ${fullname.value} <br>  Email: ${email.value} <br> Phone Number: ${phone.value} <br>  Message: ${messa.value} <br> ';


    Email.send({
        Host : "smtp.elasticemail.com",
        Username : "nidhiparihar1010@gmail.com",
        Password : "p7A2AE5B7CF25D221A8F797A01F9823FD7AF5",
        To : 'nidhiparihar1010@gmail.com',
        From : "nidhiparihar1010@gmail.com",
        Subject : subject.value,
        Body : bodymessgae
    }).then(
      message => alert(message)
    );
}

form.addEventListener("submit", (e) => 
{
    e.preventDefault();


    sendMail();
});